# Raylib C++ Starter Template for VSCode

A cross-platform starter template for Raylib C++ projects using VSCode.

## Setup Instructions

### macOS

1. Install Homebrew if not installed:

   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

2. Install Raylib:

   ```bash
   brew install raylib
   ```

3. Build and run:
   ```bash
   make
   ./game
   ```

## ✅ Basic Make Commands (Mac OS)

```make -> Runs the default target in the Makefile (usually builds the app)
make simple -> Runs simple cout statements.
make all -> Builds all targets (if defined in Makefile)
make run -> Runs the compiled program (you define this target)
make clean -> Removes compiled files (e.g., .o, binaries)
make rebuild -> Cleans and rebuilds the project
```
### Linux

1. Install dependencies:

   ```bash
   sudo apt-get update
   sudo apt-get install raylib libgl1-mesa-dev libglfw3-dev
   ```

2. Build and run:
   ```bash
   make
   ./game
   ```

### Windows

1. Install dependencies:

   - Download and install raylib from: https://www.raylib.com/download.html
   - Install MinGW-w64 from: https://sourceforge.net/projects/mingw-w64/

2. Update paths in Makefile:

   - Set RAYLIB_INSTALL_PATH to your raylib installation directory
   - Set RAYLIB_H_INSTALL_PATH to your raylib include directory

3. Build and run:
   ```bash
   mingw32-make
   game.exe
   ```

## Project Structure

- `main.cpp`: Your main game code
- `Makefile`: Cross-platform build configuration
- `.vscode/`: VSCode configuration files

## Features

- Cross-platform compatibility (Windows, Linux, macOS)
- Simple and clean project structure
- Easy to modify and extend
- Ready to use with VSCode
- Modern C++14 support

## Building

Simply run `make` in the terminal to build the project. The executable will be generated as:

- `game` (macOS/Linux)
- `game.exe` (Windows)

# Video Tutorial

<p align="center">
  <img src="preview.jpg" alt="" width="800">
</p>

<p align="center">
🎥 <a href="https://www.youtube.com/watch?v=PaAcVk5jUd8">Video Tutorial on YouTube</a>
</p>

<br>
<br>
<p align="center">
| 📺 <a href="https://www.youtube.com/channel/UC3ivOTE5EgpmF2DHLBmWIWg">My YouTube Channel</a>
| 🌍 <a href="https://www.programmingwithnick.com">My Website</a> | <br>
</p>
